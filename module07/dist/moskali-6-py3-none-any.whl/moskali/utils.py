import calendar


def get_calendar_year(year):
    return calendar.calendar(year)


def get_month_name(month):
    return calendar.month_name[month]
