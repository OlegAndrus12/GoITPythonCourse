MENU = """
    # 1: add new record
    # 2: show statistics
    # 3: show calendar
    # 4: show statistics per month
    # 5: display menu
    # 6: exit
"""
